package com.hms.daos;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hms.entities.Employee;

public interface IEmployeeDao extends JpaRepository<Employee,Integer> {

		@Modifying
		@Query(value="insert into employees (id,user_id,dob,hire_date,salary) values(:id,:userId,:dob,:hireDate,:salary)",nativeQuery = true)
		int insertIntoEmployeesTable(@Param("id") int empId,@Param("userId") int userId,@Param("dob") Date dob,@Param("hireDate")Date hireDate,@Param("salary") double salary);
		
		@Query(value="select id from employees where user_id=(select id from users where email= :email)",nativeQuery = true)
		int getEmpIdByEmail(@Param("email")String email);

}
