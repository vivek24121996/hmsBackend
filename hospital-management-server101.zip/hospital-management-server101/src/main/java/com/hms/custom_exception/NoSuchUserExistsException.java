package com.hms.custom_exception;

public class NoSuchUserExistsException extends Exception {

	public NoSuchUserExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
