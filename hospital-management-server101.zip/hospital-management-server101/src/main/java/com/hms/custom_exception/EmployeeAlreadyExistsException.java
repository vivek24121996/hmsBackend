package com.hms.custom_exception;

public class EmployeeAlreadyExistsException extends RuntimeException {

	public EmployeeAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
