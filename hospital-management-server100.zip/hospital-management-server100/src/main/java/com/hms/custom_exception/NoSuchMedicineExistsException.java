package com.hms.custom_exception;

public class NoSuchMedicineExistsException extends RuntimeException {

	public NoSuchMedicineExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
