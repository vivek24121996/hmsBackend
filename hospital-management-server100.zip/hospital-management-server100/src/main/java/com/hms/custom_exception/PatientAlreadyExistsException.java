package com.hms.custom_exception;

public class PatientAlreadyExistsException extends RuntimeException {

	public PatientAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
