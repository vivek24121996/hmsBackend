package com.hms.dtos;

public class UserAthenticatePojo {
	

}
